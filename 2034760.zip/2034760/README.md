For testing login features please use
Email: dave@gmail.com
Password:dave123
Or if you prefer make your own account and then log out and log back in

For testing sign up (use any email,username and password you like. Password should 6+ characters long)

Project Name: Bites - A Restaurant Review App

Description: My app allows the user to submit a review for a restaurant if they make an account and sign in.
Guests can use the app to view a list of reviews submitted, they can not submit a review
but only a user can edit their own review. Guests can have their own list of favourites restaurants but they won't receive any currency in their account.

Users & Guests can view the list of restaurants on the app. I have included app settings(including enabling location), only the user can favourite restaurants and this will be added into their favourites list which they can view from the appbar (Additional Feature).
Once a user logs in they are given 5 coins, submitting a review gives them more coins to spend on vouchers for restaurants. Once a user reaches a x coins they would be able to have access to an "exclusive website" to get food vouchers. In this case I have just used Unidays. (Additional Feature).

Users can add an image from their camera roll to a review before submitting, if you're running this via the emulator you have to add images from your desktop via drag and drop to the settings -> storage ->images and then when you click on "upload image" in the app the images will appear there.
I have provided a folder of images for you to test with.

All these external aspects such as Reviews, Restaurants, Users, Favourites and Currency are all managed and stored in a FireStore Database.

Images are loaded using Picasso API

I have designed my app in a way that should be easy to navigate and follow, unfortunately due to struggling to implement certain features it meant it didn't turn out exactly
as I expected and given more time I would implement features further. However I believe I have added most of the functionality required.

In regards to location, I did attempt to add this functionality however it would open google maps and not get the selected location and I couldn't fix this therefore I commented out all section relating to this, but it is still there for your consideration.

A feature I was not able to implement in time was the user being able to add their location to a review and this be added to my firestore database. I had a lot of issues getting location to work so I decided to focus on other aspects.

Please note the app may run slow at first run
