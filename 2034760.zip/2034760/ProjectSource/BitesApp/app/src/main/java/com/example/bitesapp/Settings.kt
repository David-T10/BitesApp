package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import com.google.firebase.auth.FirebaseAuth


/*this class would've implemented the user being able to change location setting inside the app.
* However as mentioned in the readMe due to issues with using location in android studio I decided to
* not waste too much time implemented it as it's not part of the spec.*/
class Settings : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)
        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate((R.menu.toolbar_layout), menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Home -> {
                launchWriteAReview()
                return true
            }
            R.id.favourites -> {
                if(mAuth.currentUser!=null){
                    launchFavouritesFromAppBar()
                }else{
                    Toast.makeText(this, "You must be logged in to view your favourites", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.profile -> {
                if(mAuth.currentUser!=null) {
                    launchProfileFromAppBar()
                } else {
                    Toast.makeText(this, "You must be logged in to view your profile", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.action_settings -> {
                launchSettingsFromAppBar()
                return true
            }
            R.id.action_logout -> {
                if (currentUser != null) {
                    FirebaseAuth.getInstance().signOut()
                    launchStartScreen()
                } else {
                    launchStartScreen()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }

    private fun launchWriteAReview(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Write review",e)
        }
    }

    private fun launchProfileFromAppBar(){
        try{
            val newIntent = Intent(this, UserProfile::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchFavouritesFromAppBar(){
        try{
            val newIntent = Intent(this, Favourites::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchSettingsFromAppBar(){
        try{
            val newIntent = Intent(this, Settings::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }
}