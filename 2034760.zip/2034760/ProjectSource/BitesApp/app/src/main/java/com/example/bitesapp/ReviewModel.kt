package com.example.bitesapp

import android.widget.RatingBar
import java.util.*


data class ReviewModel(
    var author: String? = null,
    var reviewText: String? = null,
    var rating: String? = null,
    var userID: String? = null,
    var reviewID: String? = null,
    var img: String? = null
)