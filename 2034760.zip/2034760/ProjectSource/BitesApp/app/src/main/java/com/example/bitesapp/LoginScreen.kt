package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginScreen : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private lateinit var eEmail : EditText
    private lateinit var ePwd : EditText
    private lateinit var goToMainAppPageBtn : Button
    private lateinit var logoutBtn : Button
    private lateinit var progressBar : ProgressBar
    private var savedEmail : String? = null
    private var savedPassword : String? = null

    companion object {
        private const val KEY_EMAIL = "key_email"
        private const val KEY_PASSWORD = "key_password"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_screen)

        eEmail = findViewById(R.id.login_email_input)
        ePwd = findViewById(R.id.login_password_input)
        progressBar = findViewById(R.id.loginProgressBar)
        goToMainAppPageBtn = findViewById(R.id.loginbutton)
        logoutBtn = findViewById(R.id.logoutbutton)


        //logging in using fireBase email and password auth
        goToMainAppPageBtn.setOnClickListener { v ->
            progressBar.visibility = View.VISIBLE
            mAuth.signInWithEmailAndPassword(eEmail.text.toString(),ePwd.text.toString()).addOnCompleteListener(this){
                    task -> if (task.isSuccessful){
                currentUser = mAuth.currentUser
                savedEmail = null
                savedPassword = null
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                launchMainPage()
            } else {
                progressBar.visibility = View.INVISIBLE
                Toast.makeText(this, "Wrong login details, Login Failed", Toast.LENGTH_SHORT).show()
            }
            }
        }
    }

    //if a user is logged in when the application restarts or they attempt to sign up with a new user
    // then a log out button will be displayed */
    override fun onStart() {
        super.onStart()
        if(currentUser != null){
            showLogOutButton()
        }
        logoutBtn.setOnClickListener {
            removeLogOutButton()
        }
    }

    // Save the email and password to the bundle before the activity is destroyed
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_EMAIL, eEmail.text.toString())
        outState.putString(KEY_PASSWORD, ePwd.text.toString())
    }

    // Restore the saved email and password after abnormal destruction e.g. screen rotation
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        savedEmail = savedInstanceState.getString(KEY_EMAIL)
        savedPassword = savedInstanceState.getString(KEY_PASSWORD)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        eEmail.setText(savedEmail)
        ePwd.setText(savedPassword)
    }

    private fun showLogOutButton(){
        Toast.makeText(this, "User currently logged in", Toast.LENGTH_SHORT).show()
        logoutBtn.visibility = View.VISIBLE
        logoutBtn.setOnClickListener{
            FirebaseAuth.getInstance().signOut()
        }
    }

    private fun removeLogOutButton(){
        Toast.makeText(this, "User currently logged out", Toast.LENGTH_SHORT).show()
        logoutBtn.visibility = View.INVISIBLE
    }


    private fun launchMainPage(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }
}