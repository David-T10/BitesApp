package com.example.bitesapp

/*
 * Data model class to store logos and restaurant names
 */

data class RestaurantModel(
    var name: String? = null,
    var address: String? = null,
    var image: String? = null
)



