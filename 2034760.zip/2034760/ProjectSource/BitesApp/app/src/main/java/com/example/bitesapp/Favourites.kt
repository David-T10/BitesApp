package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class Favourites : AppCompatActivity() {
    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private lateinit var favRecyclerView: RecyclerView
    private lateinit var favAdapter : FavouritesAdapter
    private var favourites: ArrayList<RestaurantModel> = ArrayList()
    private val restDb = FirebaseFirestore.getInstance()
    private val usersCollection = restDb.collection("users")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.favourites)
        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)

        favRecyclerView = findViewById(R.id.favs_recycler_view)
        favAdapter = FavouritesAdapter(ArrayList())
        favRecyclerView.layoutManager = LinearLayoutManager(this)
        fetchFavouritesData()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate((R.menu.toolbar_layout), menu)
        return super.onCreateOptionsMenu(menu)
    }

    /* Handle appbar items clicks here. Where it states ...!=null is checking if user is signed in or not.
    * As some actions are only available to users when signed in e.g. Accessing user profile*/
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Home->{
                launchWriteAReview()
                return true
            }
            R.id.favourites -> {
                if(mAuth.currentUser!=null){
                    launchFavouritesFromAppBar()
                }else{
                    Toast.makeText(this, "You must be logged in to view your favourites", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.profile -> {
                if(mAuth.currentUser!=null) {
                    launchProfileFromAppBar()
                } else {
                    Toast.makeText(this, "You must be logged in to view your profile", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.action_settings -> {
                launchSettingsFromAppBar()
                return true
            }
            R.id.action_logout -> {
                if (currentUser != null) {
                    FirebaseAuth.getInstance().signOut()
                    launchStartScreen()
                } else {
                    launchStartScreen()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    /*Retrieves user's favourited restaurants from the firestore database. Each User has a collection within their fields
    * that stores their favourite restaurants*/
    private fun fetchFavouritesData() {
        favourites.clear()
        usersCollection.document(currentUser!!.uid).collection("favourites").orderBy("name", Query.Direction.ASCENDING).get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    for (document in task.result!!) {
                        favourites.add(document.toObject(RestaurantModel::class.java))
                    }
                    favAdapter.updateData(favourites)
                    favRecyclerView.adapter = favAdapter
                } else {
                    Log.e("Firestore", "Error getting documents: ", task.exception)
                }
            }
    }

    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }

    private fun launchWriteAReview(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Write review",e)
        }
    }

    private fun launchProfileFromAppBar(){
        try{
            val newIntent = Intent(this, UserProfile::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchFavouritesFromAppBar(){
        try{
            val newIntent = Intent(this, Favourites::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchSettingsFromAppBar(){
        try{
            val newIntent = Intent(this, Settings::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }
}