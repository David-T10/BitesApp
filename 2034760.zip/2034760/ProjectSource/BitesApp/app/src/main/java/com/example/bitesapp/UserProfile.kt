package com.example.bitesapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.graphics.Color
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class UserProfile : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private val db = FirebaseFirestore.getInstance()
    private val usersCollection = db.collection("users")
    private lateinit var profileUserName : TextView
    private lateinit var profileEmail : TextView
    private lateinit var rCoinsNumber : TextView
    private lateinit var claimVoucherBtn: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_profile)
        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)

        profileUserName = findViewById(R.id.profileUserName)
        profileEmail = findViewById(R.id.profileEmail)
        rCoinsNumber = findViewById(R.id.rCoinsNumber)
        claimVoucherBtn = findViewById(R.id.claimVoucher)

        //when enough coins (10), user can launch into an "exclusive discount partner website"
        // for food discounts. Button changes to reflect the user has enough coins.*/
        checkIfEnoughCoins { enoughCoins->
                if(enoughCoins){
                    val voucherUrl = getString(R.string.voucher_url)
                    claimVoucherBtn.setBackgroundColor(Color.RED)
                    claimVoucherBtn.setTextColor(Color.WHITE)
                    claimVoucherBtn.setOnClickListener {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(voucherUrl))
                        startActivity(intent)
                    }
                }else {
                    claimVoucherBtn.setOnClickListener {
                        Toast.makeText(this, "You need at least 10 coins to claim a voucher", Toast.LENGTH_SHORT).show()
                    }
                }

        }

        usersCollection.document(currentUser!!.uid).get().addOnSuccessListener { doc ->
            profileUserName.text = doc.getString("name")
        }
        usersCollection.document(currentUser!!.uid).get().addOnSuccessListener { doc ->
            profileEmail.text = doc.getString("email")
        }
        usersCollection.document(currentUser!!.uid).get().addOnSuccessListener { doc ->
            rCoinsNumber.text = doc.getString("Rcoins")
        }


    }

    override fun onResume() {
        super.onResume()
        usersCollection.document(mAuth.currentUser!!.uid).get().addOnSuccessListener { document ->
            val currentRCoin = document.getString("Rcoins")?:"0"
            rCoinsNumber.text = currentRCoin
        }
        // When the activity is resumed, after being taken to the external website and navigating
    // back to the app, fetch and display the updated coin amount (Additional Feature)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate((R.menu.toolbar_layout), menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Home->{
                launchWriteAReview()
                return true
            }
            R.id.favourites -> {
                if(mAuth.currentUser!=null){
                    launchFavouritesFromAppBar()
                }else{
                    Toast.makeText(this, "You must be logged in to view your favourites", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.profile -> {
                if(mAuth.currentUser!=null) {
                    launchProfileFromAppBar()
                } else {
                    Toast.makeText(this, "You must be logged in to view your profile", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.action_settings -> {
                launchSettingsFromAppBar()
                return true
            }
            R.id.action_logout -> {
                if (currentUser != null) {
                    FirebaseAuth.getInstance().signOut()
                    launchStartScreen()
                } else {
                    launchStartScreen()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //Checks the user database to see if the user has enough coins to gain access to the website for a voucher.
    // updates the coin value. Returns true if user has enough coins*/
    private fun checkIfEnoughCoins(callback: (Boolean) -> Unit) {
        db.runTransaction { transaction ->
            val currentRCoins = transaction.get(usersCollection.document(mAuth.currentUser!!.uid)).getString("Rcoins") ?: "0"
            val currentRCoinsNumber = currentRCoins.toInt()
            var enoughCoins = false
            if (currentRCoinsNumber >= 10) {
                enoughCoins = true
                val newRCoins = currentRCoinsNumber - 10
                transaction.update(
                    usersCollection.document(mAuth.currentUser!!.uid),
                    "Rcoins",
                    newRCoins.toString()
                )
            }
            enoughCoins
        }.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val result = task.result ?: false
                callback(result)
            } else {
                Log.e("Logcat", "Transaction failed: ${task.exception}")
                callback(false)
            }
        }
    }


    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }

    private fun launchWriteAReview(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Write review",e)
        }
    }

    private fun launchProfileFromAppBar(){
        try{
            val newIntent = Intent(this, UserProfile::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchFavouritesFromAppBar(){
        try{
            val newIntent = Intent(this, Favourites::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchSettingsFromAppBar(){
        try{
            val newIntent = Intent(this, Settings::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }
}