package com.example.bitesapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso

class ReviewListAdapter(private val context: Context, private val reviews: ArrayList<ReviewModel>) :
    RecyclerView.Adapter<ReviewListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.review_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val mAuth = FirebaseAuth.getInstance()
        val review = reviews[position]
        holder.nameTextView.text = review.author
        holder.rtTextView.text = review.reviewText
        val rating = review.rating?.toFloat()?:0.0f
        holder.ratingBarView.rating = rating
        //if an image loaded from the review db exists then load it in, if not then put the placeholder image
        if(review.img?.isNotEmpty() == true){
            Picasso.get().load(Uri.parse(review.img)).into(holder.imgView)}else{
            holder.imgView.setImageResource(R.drawable.placeholderpic)
        }

        /*allow a user logged in to edit their review. On binding to the recyclerview each review displayed will have an
        * edit button when the it is the user's review. When the edit button is clicked user is taken to
        * an edit screen/activity*/
        if(mAuth.currentUser!= null && mAuth.currentUser!!.uid == review.userID) {
            holder.editBtn.visibility = View.VISIBLE
            holder.editBtn.setOnClickListener {
                val reviewPicked = reviews[holder.adapterPosition]
                val intent = Intent(context, EditReview::class.java).apply{
                    putExtra("reviewID", reviewPicked.reviewID)
                    putExtra("author", reviewPicked.author)
                    putExtra("reviewText", reviewPicked.reviewText)
                    putExtra("img", reviewPicked.img)
                    putExtra("rating", reviewPicked.rating)
                }
                context.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int {
        return reviews.size
    }

    fun updateData(newList: ArrayList<ReviewModel>) {
        reviews.clear()
        reviews.addAll(newList)
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var nameTextView = itemView.findViewById(R.id.reviewUserName) as TextView
        var rtTextView = itemView.findViewById(R.id.reviewText) as TextView
        var ratingBarView = itemView.findViewById(R.id.ratingBarReview) as RatingBar
        var imgView = itemView.findViewById(R.id.reviewUserImage) as ImageView
        var editBtn = itemView.findViewById(R.id.btnEditReview) as Button

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val msg = nameTextView.text
            val snackbar = Snackbar.make(v, "$msg", Snackbar.LENGTH_LONG)
            snackbar.show()
        }
    }
}
