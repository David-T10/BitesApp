package com.example.bitesapp

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso

class RestaurantListAdapter(private val context: Context, private val restaurants: ArrayList<RestaurantModel>) :
    RecyclerView.Adapter<RestaurantListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.restaurant_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val mAuth = FirebaseAuth.getInstance()
        val currentUser = mAuth.currentUser
        val db = FirebaseFirestore.getInstance()
        val usersCollection = db.collection("users")

        Log.i("bind","binding restaurants")
        val restaurant : RestaurantModel = restaurants[position]
        holder.nameTextView.text = restaurant.name
        holder.addressTextView.text = restaurant.address
        Picasso.get().load(restaurant.image).into(holder.restImageView)

        //when binding restaurants to the screen to be displayed in recycler, access each favourite button
        // on each restaurant, when clicked the restaurant is "favourited" and added to the user's collection of
        // favourited restaurants (Additional feature)*/
        holder.favsButton.setOnClickListener {
            if (currentUser == null) {
                Toast.makeText(context, "Guest must sign in to add Favourites", Toast.LENGTH_LONG).show()
            } else {
                holder.favsButton.setImageResource(R.drawable.heart_filled)
                val favouritesCollection =
                    usersCollection.document(currentUser.uid).collection("favorites")
                favouritesCollection.get().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                            //if no favourites collection exists yet then make one
                            usersCollection.document(currentUser.uid).collection("favourites")
                                .document(restaurant.name.toString()).set(
                                mapOf(
                                    "name" to restaurant.name,
                                    "address" to restaurant.address,
                                    "image" to restaurant.image,
                                )
                            )
                    } else {
                        Log.e("task failed", "favs failed", task.exception)
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return restaurants.size
    }

    fun updateData(newList: ArrayList<RestaurantModel>) {
        restaurants.clear()
        restaurants.addAll(newList)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var nameTextView = itemView.findViewById(R.id.restaurantName) as TextView
        var addressTextView = itemView.findViewById(R.id.restaurantAddress) as TextView
        var restImageView = itemView.findViewById(R.id.restaurantImg) as ImageView
        var favsButton = itemView.findViewById(R.id.favoriteButton) as ImageButton

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val msg = nameTextView.text
            val snackbar = Snackbar.make(v, "$msg", Snackbar.LENGTH_LONG)
            snackbar.show()
        }
    }
}
