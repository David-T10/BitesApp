package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class StartScreen : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.start_screen)

        val goToLoginScreenButton = findViewById<Button>(R.id.startLoginButton)
        val goToSignupScreenButton = findViewById<Button>(R.id.startSigninButton)
        val startAsGuest = findViewById<Button>(R.id.startAsGuest)

        goToLoginScreenButton.setOnClickListener {launchLoginScreen() }
        goToSignupScreenButton.setOnClickListener{launchSignupScreen()}

        //checks if a user is logged in, then if they are logs then out so a guest mode can be launched.
        startAsGuest.setOnClickListener {
            if (currentUser != null) {
                Toast.makeText(this, "Logging out Current User", Toast.LENGTH_SHORT)
                    .show()
                FirebaseAuth.getInstance().signOut()
            }
            launchAsGuest()
        }
    }

    private fun launchLoginScreen() {
        try{
            val newIntent = Intent(this, LoginScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Login Screen",e)
        }
    }

    private fun launchSignupScreen(){
        try{
            val newIntent = Intent(this, SignupScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "SignUp Screen",e)
        }
    }

    private fun launchAsGuest(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Guest Screen",e)
        }
    }
}