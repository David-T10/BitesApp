package com.example.bitesapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso

class EditReview : AppCompatActivity() {

    private var selectedImageUri: Uri? = null
    private lateinit var imagePicker: ActivityResultLauncher<Intent>
    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private val db = FirebaseFirestore.getInstance()
    private val reviewsCollection = db.collection("reviews")
    private lateinit var selectedImageView : ImageView
    private lateinit var editImg : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edit_review)
        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)

        val editReviewText : EditText = findViewById(R.id.reviewText)
        val editAuthor : EditText = findViewById(R.id.reviewUserName)
        editImg = findViewById(R.id.reviewUserImage)
        val editRating : RatingBar = findViewById(R.id.ratingBarReview)
        val uploadNewImgBtn : Button = findViewById(R.id.uploadImgBtn)
        val saveEditsBtn : Button = findViewById(R.id.saveEditBtn)
        selectedImageView = findViewById(R.id.selectedEditImageView)

        val existingReviewID = intent.getStringExtra("reviewID")
        val existingReviewText = intent.getStringExtra("reviewText")
        val existingRating = intent.getStringExtra("rating")
        val existingImg = intent.getStringExtra("img")
        val existingAuthor = intent.getStringExtra("author")

        /*Setting the current review text, author etc which at this point is whatever I put in the layout, to
        what the user entered in the review they chose to edit.*/
        editAuthor.setText(existingAuthor)
        editReviewText.setText(existingReviewText)
        editRating.rating = existingRating!!.toFloat()
        if ((existingImg != null) && existingImg.isNotEmpty()) {
            Picasso.get().load(existingImg).into(editImg)
        }

        //checks if user changes rating when editing and sets that value to the bar.rating to be stored later.
        editRating.setOnRatingBarChangeListener {
                _,rating, _ ->
        }


        imagePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            // Check if the result code shows a successful image selection
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                handleImageSelectionResult(data)
            }
        }

        /*Once the user clicks the save button, their edits are saved into the firestore database that
        * stores all reviews, (first their old version of the review is deleted) and then they are
        * taken back to see all reviews, including the updated one*/
        saveEditsBtn.setOnClickListener {
            val newReviewText = editReviewText.text.toString()
            val newRating = editRating.rating
            val newAuthor = editAuthor.text.toString()
            val newImgUrl = editImg.tag?.toString()?:""
            val userID = currentUser!!.uid
            val newReview = ReviewModel(newAuthor,newReviewText,newRating.toString(),userID,existingReviewID,newImgUrl)

            reviewsCollection.document(existingReviewID!!).delete().addOnCompleteListener{deletionTask ->
            if (deletionTask.isSuccessful) {
                reviewsCollection.document(existingReviewID).set(newReview).addOnCompleteListener{additionTask->
                    if(additionTask.isSuccessful){
                        Toast.makeText(this, "Review saved", Toast.LENGTH_SHORT).show()
                        launchAllReviews()
                    }else {
                        Toast.makeText(this, "Failed to save review", Toast.LENGTH_SHORT).show()
                    }
            }}else {
                Toast.makeText(this, "Failed to delete old review", Toast.LENGTH_SHORT).show()
            }
            }
        }

        //when upload image button is clicked then the image intent is launched through uploadImage()
        uploadNewImgBtn.setOnClickListener{
            uploadImage()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate((R.menu.toolbar_layout), menu)
        return super.onCreateOptionsMenu(menu)
    }

    /* Handle appbar items clicks here. Where it states ...!=null is checking if user is signed in or not.
    * As some actions are only available to users when signed in e.g. Accessing user profile*/
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.Home->{
                launchWriteAReview()
                return true
            }
            R.id.favourites -> {
                if(currentUser!=null){
                    launchFavouritesFromAppBar()
                }else{
                    Toast.makeText(this, "You must be logged in to view your favourites", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.profile -> {
                if(currentUser!=null) {
                    launchProfileFromAppBar()
                } else {
                    Toast.makeText(this, "You must be logged in to view your profile", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.action_settings -> {
                launchSettingsFromAppBar()
                return true
            }
            R.id.action_logout -> {
                if (currentUser != null) {
                    FirebaseAuth.getInstance().signOut()
                    launchStartScreen()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //launches image picker intent in android
    private fun uploadImage() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        imagePicker.launch(intent)
    }

    /*checks if the data selected from the launched intent (in this case the image selected)
    * is valid, if it is then it places the image on the screen*/
    private fun handleImageSelectionResult(data: Intent?) {
        if (data != null && data.data != null) {
            selectedImageUri = data.data
            selectedImageView.setImageURI(selectedImageUri)
            selectedImageView.visibility = View.VISIBLE
            Picasso.get().load(selectedImageUri).into(editImg)
            editImg.tag = selectedImageUri
        }
    }

    private fun launchAllReviews(){
        try{
            val newIntent = Intent(this, AllReviews::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Write review error",e)
        }
    }

    private fun launchWriteAReview(){
        try{
            val newIntent = Intent(this, WriteAReview::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Write review error",e)
        }
    }

    private fun launchProfileFromAppBar(){
        try{
            val newIntent = Intent(this, UserProfile::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "activity error",e)
        }
    }

    private fun launchFavouritesFromAppBar(){
        try{
            val newIntent = Intent(this, Favourites::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchSettingsFromAppBar(){
        try{
            val newIntent = Intent(this, Settings::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }
}