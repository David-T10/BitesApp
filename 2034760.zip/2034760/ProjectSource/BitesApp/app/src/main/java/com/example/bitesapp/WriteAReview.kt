package com.example.bitesapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class WriteAReview : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private val db = FirebaseFirestore.getInstance()
    private val usersCollection = db.collection("users")
    private val reviewsCollection = db.collection("reviews")
    private lateinit var userName: String
    private lateinit var submitBtn : Button
    private lateinit var allReviewsBtn : Button
    private lateinit var allRestaurantsBtn : Button
    private lateinit var uploadImageBtn : Button
    private lateinit var locationText: TextView
    //private lateinit var selectLocationBtn: Button
    private lateinit var ratingBar: RatingBar
    private lateinit var selectedImageView : ImageView
    private var selectedImageUri: Uri? = null
    //private var selectedLocation: String? = null
    private lateinit var imagePicker: ActivityResultLauncher<Intent>
    //private lateinit var locationPicker: ActivityResultLauncher<Intent>



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.submit_review)

        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)
        submitBtn = findViewById(R.id.btnSubmitReview)
        allReviewsBtn = findViewById(R.id.viewReviewsBtn)
        allRestaurantsBtn = findViewById(R.id.viewRestaurantsBtn)
        uploadImageBtn = findViewById(R.id.btnUploadImage)
        selectedImageView = findViewById(R.id.selectedImageView)
        //locationText = findViewById(R.id.locationText)
        //selectLocationBtn = findViewById(R.id.selectLocationButton)
        ratingBar = findViewById(R.id.ratingBar)

        ratingBar.setOnRatingBarChangeListener { _,rating, _ ->
            Log.i("rating bar listen", "rating: $rating")
        }

        /* Attempt at adding location
        locationPicker =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == RESULT_OK) {
                    val data: Intent? = result.data
                    handleLocationSelectionResult(data)
                }
            }*/

        imagePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { imgResult ->
            if (imgResult.resultCode == Activity.RESULT_OK) {
                val data: Intent? = imgResult.data
                handleImageSelectionResult(data)
            }
        }

        if(currentUser==null){
            Toast.makeText(this, "Current User: Guest", Toast.LENGTH_LONG)
                .show()
        }

        submitBtn.setOnClickListener {
            val enteredReviewText: String = findViewById<EditText?>(R.id.enterReview).text.toString()
            if (enteredReviewText.isNotBlank() && currentUser != null) {
                val currentRating = ratingBar.rating
                usersCollection.document(currentUser!!.uid).get().addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        val doc = task.result
                        if(doc != null && doc.exists()){
                            userName = doc.getString("name").toString()
                            addReview(
                                userName,
                                enteredReviewText,
                                ratingBar.rating,
                                selectedImageUri?.toString()
                            )
                        } else{
                            Toast.makeText(this, "User Name doesn't exist", Toast.LENGTH_LONG)
                                .show()
                        }
                        //resetting inputs
                        findViewById<EditText>(R.id.enterReview).text.clear()
                        ratingBar.rating = 0f
                        selectedImageView.setImageResource(R.drawable.placeholderpic)
                    } else {
                        Toast.makeText(this, "Failed to submit", Toast.LENGTH_LONG)
                            .show()
                       Log.e("Logcat","Failed due to ",task.exception)
                    }
                }
            } else {
                if(currentUser == null){
                    Toast.makeText(this, "You must have an account to submit a review", Toast.LENGTH_LONG)
                        .show()
                } else {
                    Toast.makeText(this, "Must enter text to add review", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }

        /*selectLocationBtn.setOnClickListener {
            if(currentUser!=null){
                pickLocation()
                } else{
                Toast.makeText(this, "You must have an account to submit an image", Toast.LENGTH_LONG)
                    .show()
                }
        }*/

        uploadImageBtn.setOnClickListener{
            if(currentUser!=null) {
                uploadImage()
            } else {
                Toast.makeText(this, "You must have an account to submit an image", Toast.LENGTH_LONG)
                    .show()
            }
        }

        allReviewsBtn.setOnClickListener{
            launchAllReviewsScreen()
        }

        allRestaurantsBtn.setOnClickListener{
            launchRestaurantsScreen()
        }
    }


        override fun onCreateOptionsMenu(menu: Menu?): Boolean {
            menuInflater.inflate((R.menu.toolbar_layout), menu)
            return super.onCreateOptionsMenu(menu)
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.Home->{
                    launchStartScreen()
                    return true
                }
                R.id.favourites -> {
                    if(mAuth.currentUser!=null){
                        launchFavouritesFromAppBar()
                    }else{
                        Toast.makeText(this, "You must be logged in to view your favourites", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                R.id.profile -> {
                    if(currentUser!=null) {
                        launchProfileFromAppBar()
                    } else {
                        Toast.makeText(this, "You must be logged in to view your profile", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                R.id.action_settings -> {
                    launchSettingsFromAppBar()
                    return true
                }
                R.id.action_logout -> {
                    if (currentUser != null) {
                        FirebaseAuth.getInstance().signOut()
                        launchStartScreen()
                    } else {
                        launchStartScreen()
                    }
                    return true
                }
            }
            return super.onOptionsItemSelected(item)
        }

    private fun uploadImage() {
        // Launch an image picker intent
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        imagePicker.launch(intent)
    }

    /*
    private fun pickLocation() {
        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
        locationPicker.launch(mapIntent)
    }*/

    private fun handleImageSelectionResult(data: Intent?) {
        if (data != null && data.data != null) {
            selectedImageUri = data.data
            selectedImageView.setImageURI(selectedImageUri)
            selectedImageView.visibility = View.VISIBLE
        }
    }

    /*
    @SuppressLint("SetTextI18n")
    private fun handleLocationSelectionResult(data: Intent?) {
        if (data != null) {
            val locationUri = data.data
            if (locationUri != null) {
                selectedLocation = getLocationFromUri(locationUri)
                locationText.text = "Selected Location: $selectedLocation"
            } else {
                locationText.text = "No location selected"
            }
        }
    }

    private fun getLocationFromUri(uri: Uri): String {
        val locLat = uri.getQueryParameter("lat")
        val locLong = uri.getQueryParameter("lon")

        return if (locLat != null && locLong != null) {
            "Lat: $locLat, Lon: $locLong"
        } else {
            "Unknown location format"
        }
    }*/

    /*
    * Adds a review to the review database in firestore. Only a user can add a review. When
    * adding a review as part of my (additional feature) the user will receive coins
    * for submitting a review and this can be spent to get voucher*/
    private fun addReview(author: String, text: String, rating:Float, img:String?) {
        val reviewID : String = UUID.randomUUID().toString()
        val userID : String = mAuth.currentUser!!.uid
        val review = ReviewModel(author, text, rating.toString(), userID, reviewID, img)
        if (currentUser != null) {
            reviewsCollection.document(reviewID).set(review).addOnSuccessListener {
                Toast.makeText(this, "Review submitted", Toast.LENGTH_SHORT).show()
                db.runTransaction{
                    transaction ->
                    val currentRCoins = transaction.get(usersCollection.document(userID)).getString("Rcoins") ?:"0"
                    val currentRCoinsNumber = currentRCoins.toInt()
                    val newRCoins = currentRCoinsNumber + 2
                    transaction.update(usersCollection.document(userID),"Rcoins",newRCoins.toString())
                }.addOnSuccessListener {
                    Toast.makeText(this, "+2 R-COINS for Reviewing :)", Toast.LENGTH_LONG).show()
                }
            }.addOnFailureListener { e -> Log.e("error tag", "error adding review", e) }
        }else{
            Toast.makeText(this, "Guest must sign in to review", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Null",e)
        }
    }

    private fun launchAllReviewsScreen(){
        try{
            val newIntent = Intent(this, AllReviews::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities" , "Show All Reviews error",e)
        }
    }

    private fun launchRestaurantsScreen(){
        try{
            val newIntent = Intent(this, Restaurants::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Show All Restaurants error", e)
        }
    }

    private fun launchProfileFromAppBar(){
        try{
            val newIntent = Intent(this, UserProfile::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "activity error",e)
        }
    }

    private fun launchFavouritesFromAppBar(){
        try{
            val newIntent = Intent(this, Favourites::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }

    private fun launchSettingsFromAppBar(){
        try{
            val newIntent = Intent(this, Settings::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.e("Activities", "Null",e)
        }
    }
}