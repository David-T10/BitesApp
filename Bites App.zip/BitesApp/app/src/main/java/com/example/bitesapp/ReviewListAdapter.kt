package com.example.bitesapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class ReviewListAdapter(private val reviews: MutableList<ReviewModel>) :
    RecyclerView.Adapter<ReviewListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.review_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val review = reviews[position]
        holder.nameTextView.text = review.getAuthor()
        holder.rtTextView.text = review.getReviewText()
        val rating = review.getRating()?.toFloat()?:0.0f
        holder.ratingBarView.rating = rating
    }

    override fun getItemCount(): Int {
        return reviews.size
    }

    fun updateData(newList: ArrayList<ReviewModel>) {
        reviews.clear()
        reviews.addAll(newList)
        notifyDataSetChanged()
        Log.i("RecyclerView", "Data updated. Item count: ${reviews.size}")
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var nameTextView = itemView.findViewById(R.id.reviewUserName) as TextView
        var rtTextView = itemView.findViewById(R.id.reviewText) as TextView
        var ratingBarView = itemView.findViewById(R.id.ratingBarReview) as RatingBar

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val msg = nameTextView.text
            val snackbar = Snackbar.make(v, "$msg", Snackbar.LENGTH_LONG)
            snackbar.show()
        }
    }
}
