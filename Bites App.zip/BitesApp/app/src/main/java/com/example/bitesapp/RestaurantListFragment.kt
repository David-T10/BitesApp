package com.example.bitesapp

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class RestaurantListFragment : Fragment() {

    private lateinit var restRecyclerView: RecyclerView
    private lateinit var restAdapter : RestaurantListAdapter
    private lateinit var restaurants: ArrayList<RestaurantModel>
    private val restDb = FirebaseFirestore.getInstance()
    private val restaurantsCollection = restDb.collection("restaurants")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_restaurant_list, container, false)
        restRecyclerView = view.findViewById(R.id.restaurant_recycler_view)
        restRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        restaurants = arrayListOf()

        restAdapter = RestaurantListAdapter(restaurants)
        restRecyclerView.adapter = restAdapter

        fetchRestaurantData()

        return view
    }

    private fun fetchRestaurantData() {
        Log.i("Logcat","In fetch restaurant")
        restaurantsCollection.orderBy("name",Query.Direction.ASCENDING).get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    restaurants.add(document.toObject(RestaurantModel::class.java))
                    Log.i("Logcat","added restaurant")
                }
                restAdapter.updateData(restaurants)
            }
    }
}
