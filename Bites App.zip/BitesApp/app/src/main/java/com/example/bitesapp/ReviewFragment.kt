package com.example.bitesapp

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ReviewFragment : Fragment() {

    private lateinit var reviews : ArrayList<ReviewModel>
    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private val db = FirebaseFirestore.getInstance()
    private val reviewsCollection = db.collection("review")
    private val usersCollection = db.collection("users")
    private lateinit var userName: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_my_review, container, false)

        val reviewRecyclerView: RecyclerView = view.findViewById(R.id.reviewsRecyclerView)
        val reviews = fetchReviews()// Get your list of reviews from Firestore or any other source
        val reviewAdapter = ReviewListAdapter(reviews)
        val submitBtn = view.findViewById<Button>(R.id.btnSubmitReview)

        reviewRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        reviewRecyclerView.adapter = reviewAdapter

        submitBtn.setOnClickListener {
                v -> Log.i("Logcat", "Submitting review")
            val enteredReviewText : String = view.findViewById<EditText?>(R.id.enterReview).text.toString()
            if(enteredReviewText.isNotBlank() && currentUser !=null) {
                usersCollection.document(currentUser!!.uid).get().addOnSuccessListener {
                    doc -> if (doc.exists()){
                        userName = doc.getString("name").toString()
                    addReview(userName,enteredReviewText,v.findViewById<RatingBar>(R.id.ratingBarReview).rating)
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Must enter text to add review", Toast.LENGTH_LONG).show()
            }

        }

        return view

    }

    private fun fetchReviews() : ArrayList<ReviewModel>{
        reviews = ArrayList()
        reviewsCollection.get().addOnSuccessListener { documents ->
            for (review in documents){
                val reviewId = review.getString("review_id")
                val reviewText = review.getString("text")
                val reviewRating = review.getLong("rating")
                val userName = review.getString("author")
                if(userName != null && reviewText != null && reviewRating !=null) {
                    Log.i("Fetching", "RID: $reviewId")
                    Log.i("Fetching", "TEXT: $reviewText")
                    Log.i("Fetching", "Rating: $reviewRating")
                    Log.i("Fetching", "Author: $userName")
                    reviews.add(ReviewModel(userName, reviewText, reviewRating.toFloat()))
                }
            }
        }
        return reviews
    }

    private fun addReview(author: String, text: String, rating:Float) {
        val review = ReviewModel(author, text, rating)
        if (currentUser != null) {
            reviewsCollection.document(review.getReviewID()).set(review).addOnSuccessListener {
                Log.i("Review added", "review added successfully")
                Toast.makeText(requireContext(), "Review submitted", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener { e -> Log.e("error tag", "error adding review", e) }
        }else{
            Toast.makeText(requireContext(), "Guest must sign in to review", Toast.LENGTH_LONG).show()
        }
    }
}


