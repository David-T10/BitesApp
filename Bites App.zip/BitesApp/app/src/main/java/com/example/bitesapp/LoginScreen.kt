package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginScreen : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser
    private lateinit var eEmail : EditText
    private lateinit var ePwd : EditText
    private lateinit var goToMainAppPageBtn : Button
    private lateinit var logoutBtn : Button
    private lateinit var progressBar : ProgressBar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_screen)

        eEmail = findViewById(R.id.login_email_input)
        ePwd = findViewById(R.id.login_password_input)
        progressBar = findViewById(R.id.loginProgressBar)
        goToMainAppPageBtn = findViewById(R.id.loginbutton)
        logoutBtn = findViewById(R.id.logoutbutton)

        if (currentUser != null){
            Toast.makeText(this, "User currently logged in", Toast.LENGTH_SHORT).show()
            logoutBtn.visibility = View.VISIBLE
            logoutBtn.setOnClickListener{ v ->
                FirebaseAuth.getInstance().signOut()
            }
        }

        goToMainAppPageBtn.setOnClickListener { v ->
            Log.i("Logcat","Logging in")
            progressBar.visibility = View.VISIBLE
            mAuth.signInWithEmailAndPassword(eEmail.text.toString(),ePwd.text.toString()).addOnCompleteListener(this){
                    task -> if (task.isSuccessful){
                currentUser = mAuth.currentUser
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                launchMainPage(v)
            } else {
                progressBar.visibility = View.INVISIBLE
                Toast.makeText(this, "Wrong login details, Login Failed", Toast.LENGTH_SHORT).show()
            }
            }
        }
    }

    private fun launchMainPage(view: View){
        try{
            val newIntent = Intent(this, MainNav::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.i("Activities" , "Null")
        }
    }
}