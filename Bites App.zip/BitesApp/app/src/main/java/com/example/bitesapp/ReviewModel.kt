package com.example.bitesapp

import android.widget.RatingBar
import java.util.*


class ReviewModel(author: String, text: String, rating: Float) {
    private var reviewAuthor: String = author
    private var reviewText: String = text
    private  var reviewRating = rating
    private var reviewID: String = UUID.randomUUID().toString()

    fun getAuthor(): String {
        return reviewAuthor.toString()
    }

    fun getReviewText(): String{
        return reviewText.toString()
    }

    fun getRating(): Float {
        return reviewRating
    }

    fun getReviewID(): String{
        return reviewID
    }

    fun setAuthor(name: String){
        reviewAuthor = name
    }

    fun setReviewText(text: String){
        reviewText = text
    }

    fun setRating(rating: Float){
        reviewRating = rating
    }

    fun setId(id: String){
        reviewID = id
    }

}