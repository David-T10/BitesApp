package com.example.bitesapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UserProfile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_profile)
    }
}