package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button

class StartScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.start_screen)

        val goToLoginScreenButton = findViewById<Button>(R.id.startLoginButton)
        val goToSignupScreenButton = findViewById<Button>(R.id.startSigninButton)

        goToLoginScreenButton.setOnClickListener { v ->
            launchLoginScreen(v)
        }
        goToSignupScreenButton.setOnClickListener{v->launchSignupScreen(v)}

    }

    private fun launchLoginScreen(view: View){
        try{
            val newIntent = Intent(this, LoginScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.i("Activities" , "Null")
        }
    }

    private fun launchSignupScreen(view: View){
        try{
            val newIntent = Intent(this, SignupScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.i("Activities" , "Null")
        }
    }
}