package com.example.bitesapp

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore

class SignupScreen : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var db = FirebaseFirestore.getInstance()
    private lateinit var currentUser : FirebaseUser
    private lateinit var eUsername : EditText
    private lateinit var eEmail : EditText
    private lateinit var ePwd : EditText
    private lateinit var goToMainAppPageBtn : Button
    private lateinit var logoutBtn : Button
    private lateinit var progressBar : ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup_screen)

        eUsername = findViewById(R.id.signup_username_input)
        eEmail = findViewById(R.id.signup_email_input)
        ePwd = findViewById(R.id.signup_password_input)
        goToMainAppPageBtn = findViewById(R.id.signupbutton)
        logoutBtn = findViewById(R.id.logoutbutton)
        progressBar = findViewById(R.id.signupProgressBar)


        goToMainAppPageBtn.setOnClickListener { v ->
            progressBar.visibility = View.VISIBLE
            mAuth.createUserWithEmailAndPassword(eEmail.text.toString(),ePwd.text.toString()).addOnCompleteListener(this){
                    task -> if (task.isSuccessful) {
                    Toast.makeText(this, "Sign Up Successful, Logging in", Toast.LENGTH_SHORT)
                        .show()
                    val user = hashMapOf(
                        "name" to eUsername.text.toString(),
                        "email" to eEmail.text.toString(),
                        "pwd" to ePwd.text.toString()
                    )
                    db.collection("users").add(user).addOnSuccessListener { docRef ->
                        Log.d(TAG, "Doc added with ID: ${docRef.id}" )
                        currentUser = mAuth.currentUser!!
                        launchMainPage(v)
                    }.addOnFailureListener { e->Log.w(TAG, "Error adding document", e) }
                } else {
                    Toast.makeText(this, "Sign Up Failed", Toast.LENGTH_SHORT)
                        .show()
                }
                }
            }
        }

    private fun launchMainPage(view: View){
        try{
            val newIntent = Intent(this, MainNav::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.i("Activities" , "Null")
        }
    }
}