package com.example.bitesapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient

class SearchFragment : Fragment() {

    private lateinit var placesClient: PlacesClient

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Places.initialize(requireContext(), "AIzaSyAdbQfjlQuit1QAgg1aU2cVRwnSiYkuwuY")
        placesClient = Places.createClient(requireContext())

        // Implement logic to allow the user to search for restaurants using Google Places API
        // You can use AutoCompleteTextView or other UI components
    }
}