package com.example.bitesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.firebase.auth.FirebaseAuth

class MainNav : AppCompatActivity() {

    private var mAuth = FirebaseAuth.getInstance()
    private var currentUser = mAuth.currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_nav)

        val mToolbar = findViewById<Toolbar>(R.id.main_Toolbar)
        setSupportActionBar(mToolbar)

        val tabLayout = findViewById<TabLayout>(R.id.tab_layout)
        val viewPager = findViewById<ViewPager2>(R.id.pager)

        val tabTitles = resources.getStringArray(R.array.tabTitles)
        viewPager.adapter = TabAdapter(this)
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = tabTitles[0]
                1 -> tab.text = tabTitles[1]
                2 -> tab.text = tabTitles[2]
            }
        }.attach()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate((R.menu.toolbar_layout), menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val myView = findViewById<View>(R.id.main_Toolbar)
        when (item.itemId){
            R.id.favourites -> {
                val snackbar = Snackbar.make(myView, getString(R.string.favourites), Snackbar.LENGTH_LONG)
                snackbar.show()
                return true
            }
            R.id.profile -> {
                val snackbar = Snackbar.make(myView, getString(R.string.profile), Snackbar.LENGTH_LONG)
                snackbar.show()
                return true
            }
            R.id.action_settings -> {
                val snackbar = Snackbar.make(myView, getString(R.string.settings), Snackbar.LENGTH_LONG)
                snackbar.show()
                return true
            }
            R.id.action_logout -> {
                val snackbar = Snackbar.make(myView, getString(R.string.logout), Snackbar.LENGTH_LONG)
                snackbar.show()
                if(currentUser!=null){
                    FirebaseAuth.getInstance().signOut()
                    launchStartScreen()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun launchStartScreen(){
        try{
            val newIntent = Intent(this, StartScreen::class.java)
            startActivity(newIntent)
        } catch(e: Exception){
            Log.i("Activities" , "Null")
        }
    }
}