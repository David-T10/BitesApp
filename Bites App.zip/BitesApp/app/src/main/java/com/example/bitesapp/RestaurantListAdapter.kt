package com.example.bitesapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso

class RestaurantListAdapter(private val restaurants: MutableList<RestaurantModel>) :
    RecyclerView.Adapter<RestaurantListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.restaurant_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Log.i("bind","binding restaurants")
        val restaurant : RestaurantModel = restaurants[position]
        holder.nameTextView.text = restaurant.name
        holder.addressTextView.text = restaurant.address
        Picasso.get().load(restaurant.image).into(holder.restImageView)
    }

    override fun getItemCount(): Int {
        return restaurants.size
    }

    fun updateData(newList: ArrayList<RestaurantModel>) {
        restaurants.clear()
        restaurants.addAll(newList)
        Log.i("RecyclerView", "Data updated. Item count: ${restaurants.size}")
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var nameTextView = itemView.findViewById(R.id.restaurantName) as TextView
        var addressTextView = itemView.findViewById(R.id.restaurantAddress) as TextView
        var restImageView = itemView.findViewById(R.id.restaurantImg) as ImageView

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val msg = nameTextView.text
            val snackbar = Snackbar.make(v, "$msg", Snackbar.LENGTH_LONG)
            snackbar.show()
        }
    }
}
